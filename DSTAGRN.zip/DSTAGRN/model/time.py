import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 定义时间范围
minutes_per_day = 1440  # 一天的分钟数
time_range = pd.date_range(start='2024-08-17', periods=minutes_per_day, freq='T')

# 设置随机种子以确保结果可重复
np.random.seed(0)

# 生成具有波浪形的数据
def generate_wavy_data(base_value, amplitude, frequency, phase_shift, size):
    time = np.arange(size)
    wave = amplitude * np.sin(2 * np.pi * frequency * time + phase_shift)  # 生成波浪形状
    noise = np.random.normal(0, 5, size)  # 添加少量噪声
    return np.clip(base_value + wave + noise, 0, 200).astype(int)  # 确保数据在0到200之间

# 生成流量数据
data_A = generate_wavy_data(base_value=50, amplitude=30, frequency=1/1440, phase_shift=0, size=minutes_per_day)
data_B = generate_wavy_data(base_value=70, amplitude=40, frequency=1/2880, phase_shift=np.pi/4, size=minutes_per_day)
data_C = generate_wavy_data(base_value=60, amplitude=35, frequency=1/720, phase_shift=np.pi/2, size=minutes_per_day)

# 创建 DataFrame
df = pd.DataFrame({
    'Time': time_range,
    'Point_A': data_A,
    'Point_B': data_B,
    'Point_C': data_C
})

# 保存数据到 CSV 文件
df.to_csv('traffic_data_different_waves.csv', index=False)

# 绘制流量图
plt.figure(figsize=(12, 6))

plt.plot(df['Time'], df['Point_A'], label='Point A', color='blue')
plt.plot(df['Time'], df['Point_B'], label='Point B', color='green')
plt.plot(df['Time'], df['Point_C'], label='Point C', color='red')

plt.title('Different Wavy Traffic Flow for Three Points Over a Day')
plt.xlabel('Time')
plt.ylabel('Traffic Flow (vehicles per minute)')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)

# 显示图形
plt.tight_layout()
plt.show()
